public class Main {
    public static void main(String[] args) {
    // Create a list of movies, including an old movie
    Film[] films = new Film[]{
            new OldMovieAdapter(new OldMovie("Casablanca", "Michael Curtiz")),
            new OldMovieAdapter(new OldMovie("The Godfather", "Francis Ford Coppola")),
            new OldMovieAdapter(new OldMovie("Inception", "Christopher Nolan"))
    };

    // Create a movie catalog and display the films
    MovieCatalog catalog = new MovieCatalog(films);
    catalog.displayMovieCatalog();
}

}