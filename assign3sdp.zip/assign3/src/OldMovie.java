public class OldMovie {

    private String movieTitle;
    private String directorName;

    public OldMovie(String title, String director) {
        this.movieTitle = title;
        this.directorName = director;
    }

    public String getName() {
        return movieTitle;
    }

    public String getDirectorName() {
        return directorName;
    }
}
