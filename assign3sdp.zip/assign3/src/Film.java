public interface Film {
    String getTitle();
    String getDirector();
}
