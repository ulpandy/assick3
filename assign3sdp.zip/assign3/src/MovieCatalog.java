public class MovieCatalog {
        private Film[] films;

        public MovieCatalog(Film[] films) {
            this.films = films;
        }

        public void displayMovieCatalog() {
            for (Film film : films) {
                System.out.println("Title: " + film.getTitle());
                System.out.println("Director: " + film.getDirector());
                System.out.println();
            }
        }
    }


