public class OldMovieAdapter implements Film {
        private OldMovie oldMovie;

        public OldMovieAdapter(OldMovie oldMovie) {
            this.oldMovie = oldMovie;
        }

        @Override
        public String getTitle() {
            return oldMovie.getName();
        }

        @Override
        public String getDirector() {
            return oldMovie.getDirectorName();
        }
    }

